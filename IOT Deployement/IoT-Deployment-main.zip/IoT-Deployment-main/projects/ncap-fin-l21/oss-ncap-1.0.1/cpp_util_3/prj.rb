require	'mxx_ru/cpp'

MxxRu::Cpp::composite_target {
}
