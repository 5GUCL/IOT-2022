/*==========================LICENSE NOTICE==========================*/
/*
 * Copyright (c) 2021 Vidcentum R&D Pvt Ltd, India.
 * License: Refer to LICENSE file of the software package.
 * Email: support@vidcentum.com
 * Website: https://vidcentum.com
*/
/*========================END LICENSE NOTICE========================*/

#ifndef _PM_ODP_NCAP_SYS_UTILS_SI_UNITS_H_
#define _PM_ODP_NCAP_SYS_UTILS_SI_UNITS_H_

#define EU_FACTOR_NAME_MAX_LEN     (32)
#define EU_QUANTITY_NAME_MAX_LEN   (32)


#endif /* _PM_ODP_NCAP_SYS_UTILS_SI_UNITS_H_ */