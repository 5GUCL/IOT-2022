Build using clang.
$ cd pm-fin-l21
$ mkdir build
$ cd build
$ export CC=/usr/bin/clang
$ export CXX=/usr/bin/clang++
$ cmake ..
$ make -j4

// Logger
ncap-fin-l21
file: run/ncap-fin-l21-logs/l21.log